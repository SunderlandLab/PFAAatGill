rm(list = ls())

library(deSolve)
library(ggplot2)
library(dplyr)

# ====================================================================
# STREAMLINED FISH PBTK MODEL – PFUnDA VERSION
# ====================================================================

# SIMULATION TIME PARAMETERS
days_uptake     <- 100       # Duration of uptake phase (days)
days_depuration <- 100       # Duration of depuration phase (days)
t_end_up        <- days_uptake * 86400      # Convert to seconds
t_end_dep       <- days_depuration * 86400  # Convert to seconds

# FISH PHYSIOLOGY
FW <- 8                      # Fish weight (g)
g  <- 4.9e-3                 # Growth rate (g/d)

# Membrane and transport parameters
A_gill   <- 13                 # Gill membrane area (cm2)
A_tissue <- 166                # Total capillary surface area for tissue of body (cm2)
X_mem    <- 1e-4               # Gill membrane thickness (cm)
X_ABL    <- 0.016              # Aqueous boundary layer thickness (cm)

# Volume fractions of fish organs/tissues
Vf_gill    <- 0.02385
Vf_blood   <- 0.365
Vf_liver   <- 0.0114
Vf_kidney  <- 0.0084
Vf_muscle  <- 0.465
Vf_adipose <- 0.0089
Vf_tissue  <- 1 - Vf_blood

# Blood composition parameters
Vf_lipid_blood             <- 0.0092
Vf_phospholipids_blood     <- 0.0092
Vf_protein_function_blood  <- 0.0292051
Vf_protein_structure_blood <- 0.0119949
Vf_nonlipid_blood          <- 0.00433
Vf_water_blood             <- 0.93697

# Water and DOC parameters
V_water     <- 45000             # Water volume (cm3) - 45L
C_DOC       <- 1e-6              # DOC concentration (kg/L)
DOC_density <- 1.8               # kg DOC/L DOC

# ====================================================================
# CHEMICAL-SPECIFIC PARAMETERS: PFUnDA
# ====================================================================

chemical_name <- "PFUnDA"

# Molecular weight (from table)
MW <- 564.09

# Partition coefficients (log scale) – using second table mapping:
# logDOW  -> logKow
# logDMW  -> logKmw
# logDFPW -> logKfpw
# logDSPW -> logKspw
# logDNW  -> logKnw
logKow  <- 4.05  # logDOW (PFUnDA)
logKmw  <- 5.22  # logDMW
logKfpw <- 4.74  # logDFPW
logKspw <- 3.42  # logDSPW
logKnw  <- 4.05  # logDNW
logKoc  <- 4.2   # from first table

# Convert log values to linear scale
K_lipid_water        <- 10^logKow
K_membrane_water     <- 10^logKmw
K_protein_blood      <- 10^logKfpw
K_protein_structural <- 10^logKspw
K_nonlipid_water     <- 10^logKnw
K_DOC_water          <- 10^logKoc

# Gill membrane composition
Vf_ph <- 0.6   # Volume fraction phospholipids in membrane
Vf_fp <- 0.4   # Volume fraction proteins in membrane

# Membrane-water partition coefficient
K_mem <- K_membrane_water * Vf_ph + K_protein_blood * Vf_fp

# Tissue-water partition coefficients (PFUnDA row)
K_gill_water    <- 3085.80809
K_blood_water   <- 2471.5002
K_liver_water   <- 2695.43738
K_kidney_water  <- 3422.2675
K_muscle_water  <- 2630.267992
K_adipose_water <- 11220.18454

K_tissue_water <- (K_liver_water * Vf_liver + 
                   K_kidney_water * Vf_kidney + 
                   K_muscle_water * Vf_muscle + 
                   K_adipose_water * Vf_adipose + 
                   K_gill_water * Vf_gill) / Vf_tissue

# Renal elimination rate (PFUnDA row, 1/s)
k_e <- 0    # given as 0 in your table

# ====================================================================
# EXPOSURE PARAMETERS
# ====================================================================

# Water concentration (ug/cm3 = mg/L)
C_water <- 1e-3              # 1 ug/L exposure concentration

# Calculate free and bound fractions in water (initially)
C_free_water_initial <- C_water / (1 + K_DOC_water * C_DOC)
C_bound_DOC_initial  <- C_water - C_free_water_initial

# ====================================================================
# TRANSPORT PARAMETERS (INITIAL VALUES; SOME UPDATED IN recalc_derived)
# ====================================================================

# Diffusivity calculations (function of MW)
D_aq   <- 10^(-4.13 - 0.453*log10(MW)) * 1.348  # Aqueous diffusivity (cm2/s)
D_mem  <- D_aq / 10                             # Membrane diffusivity
D_DOC  <- 4.765e-06                             # DOC diffusivity (cm2/s)

# Treat D_free as primitive for sensitivity analysis
D_free <- 1.52e-4 * (MW/1.8)^(-0.64)            # Free water diffusivity (cm2/s)

# P_mem also treated as primitive
P_mem  <- (K_mem * D_mem) / X_mem               # Apparent membrane permeability (cm/s)

# Permeability calculations
P_ABL   <- (D_free + D_DOC * K_DOC_water * C_DOC) / X_ABL  # ABL permeability
P_gill  <- 1/(1/P_ABL + 1/P_mem)                 # Effective permeability
P_tissue <- (K_membrane_water * D_mem) / X_mem    # tissue body permeability

# Desorption rate constants for equilibration (1/s)
k_des <- 0.1

# Volume of DOC phase
V_DOC <- C_DOC * (V_water/1000) * (1/DOC_density) * 1000

# ====================================================================
# Helper to recompute derived quantities after any parameter change
# D_free and P_mem are treated as primitives and are NOT overwritten.
# ====================================================================

recalc_derived <- function() {
  # DOC volume
  V_DOC <<- C_DOC * (V_water/1000) * (1/DOC_density) * 1000
  
  # Water/DOC partitioning
  C_free_water_initial <<- C_water / (1 + K_DOC_water * C_DOC)
  C_bound_DOC_initial  <<- C_water - C_free_water_initial
  
  # Diffusivity that depends on MW
  D_aq   <<- 10^(-4.13 - 0.453*log10(MW)) * 1.348
  D_mem  <<- D_aq / 10
  
  # Do NOT overwrite D_free or P_mem – they are primitives for sensitivity
  # D_free <<- 1.52e-4 * (MW/1.8)^(-0.64)
  # P_mem  <<- (K_mem * D_mem) / X_mem
  
  # Permeabilities using current D_free and P_mem
  P_ABL  <<- (D_free + D_DOC * K_DOC_water * C_DOC) / X_ABL
  P_gill  <<- 1/(1/P_ABL + 1/P_mem)
  P_tissue <<- (K_membrane_water * D_mem) / X_mem
  
  # Lumped tissue partition coefficient
  K_tissue_water <<- (K_liver_water * Vf_liver + 
                      K_kidney_water * Vf_kidney + 
                      K_muscle_water * Vf_muscle + 
                      K_adipose_water * Vf_adipose + 
                      K_gill_water * Vf_gill) / Vf_tissue
}

# Initialize derived quantities once
recalc_derived()

# ====================================================================
# ODE MODEL FOR UPTAKE PHASE
# ====================================================================

uptake_model <- function(t, y, parms) {
  # State variables
  C_free_water  <- y[1]
  C_bound_DOC   <- y[2]
  C_free_blood  <- y[3]
  C_bound_blood <- y[4]
  C_tissue      <- y[5]
  
  # Current fish weight and blood volume (growth)
  FW_t    <- FW + g * (t/86400)
  V_blood <- FW_t * Vf_blood
  V_tissue  <- FW_t * Vf_tissue
  
  growth_dilution_rate <- (g / FW_t) / 86400
  
  # Volumes of blood components
  V_lipid         <- V_blood * Vf_lipid_blood
  V_phospholipids <- V_blood * Vf_phospholipids_blood 
  V_protein       <- V_blood * Vf_protein_function_blood + V_blood * Vf_protein_structure_blood
  V_nonlipid      <- V_blood * Vf_nonlipid_blood
  V_colloids      <- V_lipid + V_phospholipids + V_protein + V_nonlipid
  
  # Fluxes between compartments (ug/s)
  M_water_blood   <- P_gill * A_gill * (C_free_water - C_free_blood)
  M_blood_tissue  <- P_tissue * A_tissue * (C_free_blood - C_tissue / K_tissue_water)
  M_renal_el      <- k_e * V_blood * C_free_blood
  
  # Fluxes within blood compartment
  M_colloids_free <- k_des * V_colloids * (C_bound_blood - C_free_blood * K_blood_water)
  
  # Fluxes in water
  M_DOC_water <- k_des * V_DOC * (C_bound_DOC - C_free_water * K_DOC_water)
  
  # Differential equations
  dC_free_water  <- (-M_water_blood + M_DOC_water + M_renal_el) / V_water
  dC_bound_DOC   <- (-M_DOC_water) / V_DOC
  dC_free_blood  <- (M_water_blood + M_colloids_free - M_blood_tissue - M_renal_el) / (V_blood * Vf_water_blood) - C_free_blood * growth_dilution_rate
  dC_bound_blood <- (-M_colloids_free) / V_colloids - C_bound_blood * growth_dilution_rate
  dC_tissue      <- (M_blood_tissue) / V_tissue - C_tissue * growth_dilution_rate
  
  return(list(c(dC_free_water, dC_bound_DOC, dC_free_blood, dC_bound_blood, dC_tissue)))
}

# ====================================================================
# ODE MODEL FOR DEPURATION PHASE
# ====================================================================

depuration_model <- function(t, y, parms) {
  # State variables
  C_free_water  <- y[1]
  C_bound_DOC   <- y[2]
  C_free_blood  <- y[3]
  C_bound_blood <- y[4]
  C_tissue      <- y[5]
  
  # Current fish weight and blood volume
  FW_t    <- FW + g * ((days_uptake + t/86400))
  V_blood <- FW_t * Vf_blood
  V_tissue  <- FW_t * Vf_tissue
  
  growth_dilution_rate <- (g / FW_t) / 86400
  
  # Volumes of blood components
  V_lipid         <- V_blood * Vf_lipid_blood
  V_phospholipids <- V_blood * Vf_phospholipids_blood 
  V_protein       <- V_blood * Vf_protein_function_blood + V_blood * Vf_protein_structure_blood
  V_nonlipid      <- V_blood * Vf_nonlipid_blood
  V_colloids      <- V_lipid + V_phospholipids + V_protein + V_nonlipid
  
  # Fluxes between compartments
  M_water_blood   <- P_gill * A_gill * (C_free_water - C_free_blood)
  M_blood_tissue  <- P_tissue * A_tissue * (C_free_blood - C_tissue / K_tissue_water)
  M_renal_el      <- k_e * V_blood * C_free_blood
  
  # Fluxes in water
  M_DOC_water   <- k_des * V_DOC * (C_bound_DOC - C_free_water * K_DOC_water)
  
  # Fluxes in blood
  M_colloids_free <- k_des * V_colloids * (C_bound_blood - C_free_blood * K_blood_water)
  
  # Differential equations
  dC_free_water  <- (-M_water_blood + M_DOC_water + M_renal_el) / V_water
  dC_bound_DOC   <- (-M_DOC_water) / V_DOC
  dC_free_blood  <- (M_water_blood + M_colloids_free - M_blood_tissue - M_renal_el) / (V_blood * Vf_water_blood) - C_free_blood * growth_dilution_rate
  dC_bound_blood <- (-M_colloids_free) / V_colloids - C_bound_blood * growth_dilution_rate
  dC_tissue      <- (M_blood_tissue) / V_tissue - C_tissue * growth_dilution_rate
  
  return(list(c(dC_free_water, dC_bound_DOC, dC_free_blood, dC_bound_blood, dC_tissue)))
}

# ====================================================================
# CALCULATE TOTAL CONCENTRATIONS
# ====================================================================

calculate_total_conc <- function(out_data, phase) {
  if(phase == "uptake") {
    FW_t    <- FW + g * (out_data[,"time"]/86400)
    V_blood <- FW_t * Vf_blood
    V_tissue  <- FW_t * Vf_tissue
    
    V_lipid         <- V_blood * Vf_lipid_blood
    V_phospholipids <- V_blood * Vf_phospholipids_blood 
    V_protein       <- V_blood * Vf_protein_function_blood + V_blood * Vf_protein_structure_blood
    V_nonlipid      <- V_blood * Vf_nonlipid_blood
    V_colloids      <- V_lipid + V_phospholipids + V_protein + V_nonlipid
    
    C_blood <- (out_data[,"C_free_blood"] * V_blood * Vf_water_blood + 
                  out_data[,"C_bound_blood"] * V_colloids)/V_blood
    
    V_DOC_local   <- C_DOC * (V_water/1000) * (1/DOC_density) * 1000
    C_water_total <- out_data[,"C_free_water"] + 
      out_data[,"C_bound_DOC"] * V_DOC_local/V_water
    
    return(data.frame(
      time_days = out_data[,"time"]/86400,
      C_blood   = C_blood,
      C_tissue  = out_data[,"C_tissue"],
      C_fish    = (C_blood * V_blood + out_data[,'C_tissue'] * V_tissue)/(V_blood+V_tissue),
      C_water   = C_water_total,
      phase     = "uptake"
    ))
  } else {
    FW_t    <- FW + g * ((days_uptake + out_data[,"time"]/86400))
    V_blood <- FW_t * Vf_blood
    V_tissue  <- FW_t * Vf_tissue
    
    V_lipid         <- V_blood * Vf_lipid_blood
    V_phospholipids <- V_blood * Vf_phospholipids_blood 
    V_protein       <- V_blood * Vf_protein_function_blood + V_blood * Vf_protein_structure_blood
    V_nonlipid      <- V_blood * Vf_nonlipid_blood
    V_colloids      <- V_lipid + V_phospholipids + V_protein + V_nonlipid
    
    C_blood <- (out_data[,"C_free_blood"] * V_blood * Vf_water_blood + 
                  out_data[,"C_bound_blood"] * V_colloids)/V_blood
    
    V_DOC_local   <- C_DOC * (V_water/1000) * (1/DOC_density) * 1000
    C_water_total <- out_data[,"C_free_water"] + 
      out_data[,"C_bound_DOC"] * V_DOC_local/V_water
    
    return(data.frame(
      time_days = days_uptake + out_data[,"time"]/86400,
      C_blood   = C_blood,
      C_tissue  = out_data[,"C_tissue"],
      C_fish   = (C_blood * V_blood + out_data[,'C_tissue'] * V_tissue)/(V_blood+V_tissue),
      C_water   = C_water_total,
      phase     = "depuration"
    ))
  }
}

# ====================================================================
# Wrapper that runs the full PBTK and returns BAF, BCF, t1/2
# ====================================================================

pbtk_run <- function(do_plot = FALSE, do_print = FALSE, recalc = TRUE) {
  if (recalc) recalc_derived()
  
  # Uptake phase
  yini_up  <- c(C_free_water = C_free_water_initial, 
                C_bound_DOC  = C_bound_DOC_initial, 
                C_free_blood = 0, 
                C_bound_blood= 0, 
                C_tissue       = 0)
  times_up <- seq(0, t_end_up, length.out = 1000)
  out_uptake <- ode(y = yini_up, times = times_up, func = uptake_model, method = "lsoda", hmax = 0)
  
  # Initial conditions for depuration
  final_uptake       <- tail(out_uptake, 1)
  C_free_blood_init  <- final_uptake[,"C_free_blood"]
  C_bound_blood_init <- final_uptake[,"C_bound_blood"]
  C_tissue_init        <- final_uptake[,"C_tissue"]
  
  # Depuration phase
  yini_dep  <- c(C_free_water = 0, C_bound_DOC = 0, 
                 C_free_blood = C_free_blood_init,
                 C_bound_blood= C_bound_blood_init, 
                 C_tissue       = C_tissue_init)
  times_dep <- seq(0, t_end_dep, length.out = 1000)
  out_depuration <- ode(y = yini_dep, times = times_dep, func = depuration_model, method = "lsoda", hmax = 0)
  
  # Results
  results_uptake     <- calculate_total_conc(out_uptake, "uptake")
  results_depuration <- calculate_total_conc(out_depuration, "depuration")
  
  results_all <- rbind(
    results_uptake[,    c("time_days", "C_fish", "C_blood","C_water", "phase")],
    results_depuration[,c("time_days", "C_fish", "C_blood","C_water", "phase")]
  )
  
  # BAF at end of uptake
  BAF <- results_uptake$C_fish[nrow(results_uptake)] / C_water
  
  # Depuration kinetics (whole-body C_fish)
  dep_data <- results_depuration
  dep_data$log_C_fish <- log(dep_data$C_fish + 1e-10)
  
  elim_model <- lm(log_C_fish ~ time_days, 
                   data = dep_data[dep_data$time_days > days_uptake, ])
  k_d <- -coef(elim_model)[2]  # 1/day
  
  half_life <- log(2) / k_d
  
  # Terminal-phase k_d and t1/2 from C_blood (second half of depuration)
  dep_data$dep_time    <- dep_data$time_days - days_uptake
  dep_data$log_C_blood <- log(dep_data$C_blood + 1e-10)
  
  dep_term <- subset(dep_data, dep_time >= (days_depuration / 2))
  
  if (nrow(dep_term) >= 2 && all(is.finite(dep_term$log_C_blood))) {
    elim_model_term       <- lm(log_C_blood ~ dep_time, data = dep_term)
    k_d_term_blood        <- -coef(elim_model_term)[2]
    half_life_term_blood  <- log(2) / k_d_term_blood
  } else {
    k_d_term_blood        <- NA_real_
    half_life_term_blood  <- NA_real_
  }
  
  # Uptake rate and BCF
  initial_slope <- (results_uptake$C_fish[2] - results_uptake$C_fish[1]) / 
    (results_uptake$time_days[2] - results_uptake$time_days[1])
  k_u_initial <- (initial_slope * k_d) / C_water
  
  nls_fit <- try(
    nls(C_fish ~ (k_u * C_water / k_d) * (1 - exp(-k_d * time_days)), 
        data = results_uptake, start = list(k_u = k_u_initial)),
    silent = TRUE
  )
  
  if(inherits(nls_fit, "try-error")) {
    k_u <- NA_real_
    BCF <- NA_real_
  } else {
    k_u <- coef(nls_fit)["k_u"]
    BCF <- k_u / k_d
  }
  
  if(do_plot) {
    plot_data <- results_all
    
    p <- ggplot(plot_data, aes(x = time_days)) +
      geom_line(aes(y = C_fish * 1000, color = "Fish"), size = 1.2) +
      geom_line(aes(y = C_water * 1000, color = "Water"), size = 1.2) +
      geom_vline(xintercept = days_uptake, linetype = "dashed", alpha = 0.5) +
      scale_color_manual(values = c("Fish" = "red", "Water" = "blue")) +
      labs(x = "Time (days)",
           y = "Concentration (ng/mL)",
           title = paste("PBTK Simulation:", chemical_name),
           subtitle = paste("BAF =", round(BAF, 2),
                            "| BCF =", ifelse(is.na(BCF), "NA", round(BCF, 2)),
                            "| t1/2 (C_fish) =", round(half_life, 2),
                            "| t1/2_term (C_blood) =",
                            ifelse(is.na(half_life_term_blood), "NA", round(half_life_term_blood, 2))
           )) +
      theme_minimal() +
      theme(legend.position = "bottom",
            plot.title = element_text(size = 14, face = "bold"),
            plot.subtitle = element_text(size = 12)) +
      annotate("text", x = days_uptake/2, 
               y = max(plot_data$C_fish)*1100, 
               label = "Uptake", size = 4) +
      annotate("text", x = days_uptake + days_depuration/2, 
               y = max(plot_data$C_fish)*1100, 
               label = "Depuration", size = 4)
    
    print(p)
  }
  
  if(do_print) {
    cat("\n========================================\n")
    cat("SIMULATION SUMMARY –", chemical_name, "\n")
    cat("========================================\n")
    cat("Exposure concentration:", C_water*1000, "ng/mL\n")
    cat("Uptake duration:", days_uptake, "days\n")
    cat("Depuration duration:", days_depuration, "days\n")
    cat("----------------------------------------\n")
    cat("Bioaccumulation Factor (BAF):", round(BAF, 2), "\n")
    cat("Bioconcentration Factor (BCF):", ifelse(is.na(BCF), "NA", round(BCF, 2)), "\n")
    cat("log10(BAF):", round(log10(BAF), 2), "\n")
    if(!is.na(BCF)) cat("log10(BCF):", round(log10(BCF), 2), "\n")
    cat("Half-life (C_fish, full depuration):", round(half_life, 4), "days\n")
    cat("Half-life (C_blood, terminal depuration):",
        ifelse(is.na(half_life_term_blood), "NA", round(half_life_term_blood, 4)), "days\n")
    cat("----------------------------------------\n")
    cat("Maximum fish concentration:", round(max(results_all$C_fish)*1000, 2), "ng/mL\n")
    cat("Final fish concentration:", round(tail(results_all$C_fish, 1)*1000, 4), "ng/mL\n")
    cat("========================================\n")
  }
  
  return(list(
    BAF                  = BAF,
    BCF                  = BCF,
    half_life            = half_life,
    half_life_term_blood = half_life_term_blood,
    results_all          = results_all,
    results_uptake       = results_uptake,
    results_depuration   = results_depuration
  ))
}

# ====================================================================
# One-at-a-time normalized sensitivity analysis
# ====================================================================

run_sensitivity <- function(param_names, delta = 0.01) {
  # Ensure derived quantities are consistent with current primitives
  recalc_derived()
  
  # Store baseline values of the parameters of intetissue
  base_values <- sapply(param_names, get, simplify = TRUE, USE.NAMES = TRUE)
  
  # Baseline simulation
  base_out <- pbtk_run(do_plot = FALSE, do_print = FALSE, recalc = FALSE)
  
  # Parameters treated as "macroprocesses"
  process_params <- c("P_gill", "P_tissue", "K_tissue_water")
  
  sens <- data.frame(
    Parameter                 = param_names,
    NSC_BAF                   = NA_real_,
    NSC_BCF                   = NA_real_,
    NSC_half_life             = NA_real_,
    NSC_half_life_term_blood  = NA_real_
  )
  
  for(i in seq_along(param_names)) {
    pname <- param_names[i]
    
    # Reset all parameters to baseline
    for(p in param_names) assign(p, base_values[[p]], envir = .GlobalEnv)
    recalc_derived()
    
    # Perturb selected parameter by (1 + delta)
    base_param <- base_values[[pname]]
    pert_param <- base_param * (1 + delta)
    assign(pname, pert_param, envir = .GlobalEnv)
    
    # For primitive parameters: recalc_derived inside pbtk_run
    # For macroprocess parameters: skip recalc so the scaled value is used directly
    if(pname %in% process_params) {
      pert_out <- pbtk_run(do_plot = FALSE, do_print = FALSE, recalc = FALSE)
    } else {
      pert_out <- pbtk_run(do_plot = FALSE, do_print = FALSE, recalc = TRUE)
    }
    
    d_par <- (pert_param - base_param) / base_param
    
    if(!is.na(base_out$BAF) && base_out$BAF != 0 && d_par != 0) {
      d_out <- (pert_out$BAF - base_out$BAF) / base_out$BAF
      sens$NSC_BAF[i] <- round((d_out / d_par) * 100, 3)
    }
    if(!is.na(base_out$BCF) && !is.na(pert_out$BCF) && base_out$BCF != 0 && d_par != 0) {
      d_out <- (pert_out$BCF - base_out$BCF) / base_out$BCF
      sens$NSC_BCF[i] <- round((d_out / d_par) * 100, 3)
    }
    if(!is.na(base_out$half_life) && base_out$half_life != 0 && d_par != 0) {
      d_out <- (pert_out$half_life - base_out$half_life) / base_out$half_life
      sens$NSC_half_life[i] <- round((d_out / d_par) * 100, 3)
    }
    if(!is.na(base_out$half_life_term_blood) &&
       !is.na(pert_out$half_life_term_blood) &&
       base_out$half_life_term_blood != 0 && d_par != 0) {
      d_out <- (pert_out$half_life_term_blood - base_out$half_life_term_blood) /
        base_out$half_life_term_blood
      sens$NSC_half_life_term_blood[i] <- round((d_out / d_par) * 100, 3)
    }
  }
  
  # tissueore baseline at the end
  for(p in param_names) assign(p, base_values[[p]], envir = .GlobalEnv)
  recalc_derived()
  
  sens
}

# ====================================================================
# RUN BASELINE MODEL + SENSITIVITY FOR PFUnDA
# ====================================================================

baseline <- pbtk_run(do_plot = TRUE, do_print = TRUE, recalc = TRUE)

sensitivity_params <- c(
  "K_tissue_water",
  "P_gill",
  "P_tissue",
  "P_mem",
  "D_free",
  "K_DOC_water",
  "C_DOC",
  "X_ABL",
  "X_mem"
)

sens_results <- run_sensitivity(sensitivity_params, delta = 0.01)

print(sens_results[order(abs(sens_results$NSC_BCF), decreasing = TRUE), ])

write.csv(
  sens_results,
  file = paste0("sensitivity_", chemical_name, ".csv"),
  row.names = FALSE
)
